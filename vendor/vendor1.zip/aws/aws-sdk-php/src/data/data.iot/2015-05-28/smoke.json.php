<?php
// This file was auto-generated from sdk-root/src/data/data.iot/2015-05-28/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'GetThingShadow', 'input' => [ 'thingName' => 'fake-thing', ], 'errorExpectedFromService' => true, ], ],];
