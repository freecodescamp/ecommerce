<?php
// This file was auto-generated from sdk-root/src/data/cognito-sync/2014-06-30/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'ListIdentityPoolUsage', 'input' => [], 'errorExpectedFromService' => false, ], [ 'operationName' => 'DescribeIdentityPoolUsage', 'input' => [ 'IdentityPoolId' => 'us-east-1:aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee', ], 'errorExpectedFromService' => true, ], ],];
