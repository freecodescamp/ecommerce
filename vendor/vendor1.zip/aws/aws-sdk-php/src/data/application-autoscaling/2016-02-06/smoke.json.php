<?php
// This file was auto-generated from sdk-root/src/data/application-autoscaling/2016-02-06/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'DescribeScalableTargets', 'input' => [ 'ServiceNamespace' => 'ec2', ], 'errorExpectedFromService' => false, ], ],];
