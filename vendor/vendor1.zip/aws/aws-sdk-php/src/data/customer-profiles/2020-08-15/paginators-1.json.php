<?php
// This file was auto-generated from sdk-root/src/data/customer-profiles/2020-08-15/paginators-1.json
return [ 'pagination' => [],];
