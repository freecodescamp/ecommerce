<?php
Theme::layout('homepage')
?>

<div id="app">
    <?php echo do_shortcode('[simple-slider key="home-slider"][/simple-slider]'); ?>

    <?php echo do_shortcode('[featured-product-categories title="Top Categories" description="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus blandit massa enim Nullam nunc varius."][/featured-product-categories]'); ?>

    <?php echo do_shortcode('[product-collections title="Exclusive Products"][/product-collections]'); ?>

    <?php echo do_shortcode('[banners image1="general/b-1.jpg" url1="/product-categories/headphone" image2="general/b-2.jpg" url2="/product-categories/camera" image3="general/b-3.jpg" url3="/product-categories/watches"][/banners]'); ?>

    <?php echo do_shortcode('[trending-products title="Trending Products"][[/trending-products]'); ?>

    <?php echo do_shortcode('[product-blocks featured_product_title="Featured Products" top_rated_product_title="Top Rated Products" on_sale_product_title="On Sale Products"][/product-blocks]'); ?>

    <?php echo do_shortcode('[featured-brands title="Our Brands"][/featured-brands]'); ?>

    <?php echo do_shortcode('[featured-news title="Visit Our Blog" description="Our Blog updated the newest trend of the world regularly"][/featured-news]'); ?>

    <?php echo do_shortcode('[testimonials title="Our Client Say!"][/testimonials]'); ?>

    <?php echo do_shortcode('[our-features icon1="flaticon-shipped" title1="Free Delivery" description1="Free shipping on all US order or order above $200" icon2="flaticon-money-back" title2="30 Day Returns Guarantee" description2="Simply return it within 30 days for an exchange" icon3="flaticon-support" title3="27/4 Online Support" description3="Contact us 24 hours a day, 7 days a week"][/our-features]'); ?>

    <?php echo do_shortcode('[newsletter-form title="Join Our Newsletter Now" description="Register now to get updates on promotions."][/newsletter-form]'); ?>

</div>
<?php /**PATH C:\xampp\htdocs\laravel-ecommerce-system\platform/themes/shopwise/views/index.blade.php ENDPATH**/ ?>