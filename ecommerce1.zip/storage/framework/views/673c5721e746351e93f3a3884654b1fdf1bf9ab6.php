<div class="form-group">
    <label class="control-label">Address</label>
    <input name="address" data-shortcode-attribute="content" class="form-control" placeholder="24 Roberts Street, SA73, Chester">
</div>
<?php /**PATH C:\xampp\htdocs\laravel-ecommerce-system\platform/themes/shopwise/partials/shortcodes/google-map-admin-config.blade.php ENDPATH**/ ?>