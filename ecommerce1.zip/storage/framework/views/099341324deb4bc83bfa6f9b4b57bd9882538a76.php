<div class="form-group">
    <label class="control-label"><?php echo e(trans('plugins/payment::payment.charge_id')); ?></label>
    <?php echo Form::input('text', 'charge_id', null, ['class' => 'form-control', 'placeholder' => trans('plugins/payment::payment.charge_id')]); ?>

</div>
<?php /**PATH C:\xampp\htdocs\laravel-ecommerce-system\platform/plugins/payment/resources/views//partials/payment-info-admin-config.blade.php ENDPATH**/ ?>