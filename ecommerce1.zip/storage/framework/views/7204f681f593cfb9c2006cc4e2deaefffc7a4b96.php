<div class="form-group">
    <label class="control-label"><?php echo e(__('Title')); ?></label>
    <input type="text" name="title" data-shortcode-attribute="title" class="form-control" placeholder="<?php echo e(__('Title')); ?>">
</div>
<?php /**PATH /Users/mac/workspace/shopwise/platform/themes/shopwise/partials/shortcodes/featured-brands-admin-config.blade.php ENDPATH**/ ?>