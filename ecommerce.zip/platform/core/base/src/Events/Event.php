<?php

namespace Botble\Base\Events;

abstract class Event
{
    //
}
