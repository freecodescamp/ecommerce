<div class="tools">
    <a href="#" class="collapse" data-toggle="tooltip" title="Collapse/Expand" data-original-title="Collapse/Expand"></a>
    <a href="#" class="fullscreen" data-toggle="tooltip" title="Full screen" data-original-title="Full screen"> </a>
</div>