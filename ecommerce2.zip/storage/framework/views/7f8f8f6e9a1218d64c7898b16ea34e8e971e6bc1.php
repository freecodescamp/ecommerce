<div class="form-group">
    <p><?php echo e(trans('plugins/contact::contact.shortcode_content_description')); ?></p>
</div>
<?php /**PATH C:\xampp\htdocs\laravel-ecommerce-system\platform/plugins/contact/resources/views//partials/short-code-admin-config.blade.php ENDPATH**/ ?>