<?php echo Theme::partial('header'); ?>


<?php echo Theme::content(); ?>


<?php echo Theme::partial('footer'); ?>

<?php /**PATH C:\xampp\htdocs\laravel-ecommerce-system\platform/themes/shopwise/layouts/homepage.blade.php ENDPATH**/ ?>