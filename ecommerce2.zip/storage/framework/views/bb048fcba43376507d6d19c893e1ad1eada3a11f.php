<div class="form-group">
    <label class="control-label">Featured Products Title</label>
    <input type="text" name="featured_product_title" data-shortcode-attribute="featured_product_title"
           class="form-control" placeholder="Featured Products Title">
</div>

<div class="form-group">
    <label class="control-label">Top Rated Products Title</label>
    <input type="text" name="top_rated_product_title" data-shortcode-attribute="top_rated_product_title"
           class="form-control" placeholder="Top Rated Products Title">
</div>

<div class="form-group">
    <label class="control-label">On Sale Products Title</label>
    <input type="text" name="on_sale_product_title" data-shortcode-attribute="on_sale_product_title"
           class="form-control" placeholder="On Sale Products Title">
</div>
<?php /**PATH /Users/mac/workspace/shopwise/platform/themes/shopwise/partials/shortcodes/product-blocks-admin-config.blade.php ENDPATH**/ ?>