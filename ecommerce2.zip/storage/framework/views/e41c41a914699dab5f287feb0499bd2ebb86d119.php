<div class="form-group">
    <label class="control-label"><?php echo e(__('Title')); ?></label>
    <input type="text" name="title" data-shortcode-attribute="title" class="form-control" placeholder="<?php echo e(__('Title')); ?>">
</div>

<div class="form-group">
    <label class="control-label"><?php echo e(__('Number products per page')); ?></label>
    <input type="number" name="per_page" data-shortcode-attribute="per_page" class="form-control" placeholder="<?php echo e(__('Number products per page')); ?>">
</div>
<?php /**PATH C:\xampp\htdocs\laravel-ecommerce-system\platform/themes/shopwise/partials/shortcodes/all-products-admin-config.blade.php ENDPATH**/ ?>