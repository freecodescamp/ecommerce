<div class="form-group col-12">
    <div class="form-actions">
        <div class="btn-set text-center">
            <button type="submit" name="submit" value="submit" class="btn btn-success">
                <i class="fa fa-check-circle"></i> <?php echo e(trans('core/acl::users.update')); ?>

            </button>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\laravel-ecommerce-system\platform/core/acl/resources/views//users/profile/actions.blade.php ENDPATH**/ ?>